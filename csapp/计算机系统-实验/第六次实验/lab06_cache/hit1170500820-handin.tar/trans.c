/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc71[] = "Transpose submission71";
void transpose_submit71(int M, int N, int A[N][M], int B[M][N])
{
	//int i, j;
	//int k, l;
	//int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
	//for (k = 0; k < 4; k++) {
	//	for (l = 0; l < 4; l++) {
	//		for (i = 16 * k; i < 16 * k + 16; i++) {
	//				temp0 = A[i][15 * l + 0];
	//				temp1 = A[i][15 * l + 1];
	//				temp2 = A[i][15 * l + 2];
	//				temp3 = A[i][15 * l + 3];
	//				temp4 = A[i][15 * l + 4];
	//				temp5 = A[i][15 * l + 5];
	//				temp6 = A[i][15 * l + 6];
	//				temp7 = A[i][15 * l + 7];
	//				B[15 * l + 0][i] = temp0;
	//				B[15 * l + 1][i] = temp1;
	//				B[15 * l + 2][i] = temp2;
	//				B[15 * l + 3][i] = temp3;
	//				B[15 * l + 4][i] = temp4;
	//				B[15 * l + 5][i] = temp5;
	//				B[15 * l + 6][i] = temp6;
	//				B[15 * l + 7][i] = temp7;
	//				temp0 = A[i][15 * l + 8];
	//				temp1 = A[i][15 * l + 9];
	//				temp2 = A[i][15 * l + 10];
	//				temp3 = A[i][15 * l + 11];
	//				temp4 = A[i][15 * l + 12];
	//				temp5 = A[i][15 * l + 13];
	//				temp6 = A[i][15 * l + 14];
	//				B[15 * l + 8][i] = temp0;
	//				B[15 * l + 9][i] = temp1;
	//				B[15 * l + 10][i] = temp2;
	//				B[15 * l + 11][i] = temp3;
	//				B[15 * l + 12][i] = temp4;
	//				B[15 * l + 13][i] = temp5;
	//				B[15 * l + 14][i] = temp6;
	//		}
	//	}
	//}
	//for (i= 0; i < 16; i++) {
	//	temp0 = A[4 * i + 0][60];
	//	temp1 = A[4 * i + 1][60];
	//	temp2 = A[4 * i + 2][60];
	//	temp3 = A[4 * i + 3][60];
	//	B[60][4 * i + 0] = temp0;
	//	B[60][4 * i + 1] = temp1;
	//	B[60][4 * i + 2] = temp2;
	//	B[60][4 * i + 3] = temp3;
	//}
	//for (i = 64; i < 67; i++) {
	//	for (j = 0; j < 61; j++) {
	//		B[j][i] = A[i][j];
	//	}
	//}
	int k, l;
	int i, j;
	int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
	for (k = 0; k + 16 < N; k += 16) {
		for (l = 0; l + 16 < M; l += 16){
			for (i = k; i < k + 16; i++){
				temp0 = A[i][l + 0];
				temp1 = A[i][l + 1];
				temp2 = A[i][l + 2];
				temp3 = A[i][l + 3];
				temp4 = A[i][l + 4];
				temp5 = A[i][l + 5];
				temp6 = A[i][l + 6];
				temp7 = A[i][l + 7];
				B[l + 0][i] = temp0;
				B[l + 1][i] = temp1;
				B[l + 2][i] = temp2;
				B[l + 3][i] = temp3;
				B[l + 4][i] = temp4;
				B[l + 5][i] = temp5;
				B[l + 6][i] = temp6;
				B[l + 7][i] = temp7;

				temp0 = A[i][l + 8];
				temp1 = A[i][l + 9];
				temp2 = A[i][l + 10];
				temp3 = A[i][l + 11];
				temp4 = A[i][l + 12];
				temp5 = A[i][l + 13];
				temp6 = A[i][l + 14];
				temp7 = A[i][l + 15];
				B[l + 8][i] = temp0;
				B[l + 9][i] = temp1;
				B[l + 10][i] = temp2;
				B[l + 11][i] = temp3;
				B[l + 12][i] = temp4;
				B[l + 13][i] = temp5;
				B[l + 14][i] = temp6;
				B[l + 15][i] = temp7;

			}
		}
	}
		
	for (i = k; i < N; i++)
		for (j = 0; j < M; j++)
			B[j][i] = A[i][j];
	for (i = 0; i < k; i++)
		for (j = l; j < M; j++)
			B[j][i] = A[i][j];
}
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	int i, j;
	int k, l;
	int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
	int val0, val1, val2, val3, val4, val5, val6, val7;
	if ((M == 64) && (N == 64))
	{
		for (k = 0; k < 8; k++) {
			for (l = 0; l < 8; l++) {
				for (i = 0; i < 4; i++) {//��һ��4x8�ĳ�����ת����ֵ��B��,ǰ4x4����������ת��
					temp0 = A[8 * l + i][8 * k + 0];
					temp1 = A[8 * l + i][8 * k + 1];
					temp2 = A[8 * l + i][8 * k + 2];
					temp3 = A[8 * l + i][8 * k + 3];
					temp4 = A[8 * l + i][8 * k + 4];
					temp5 = A[8 * l + i][8 * k + 5];
					temp6 = A[8 * l + i][8 * k + 6];
					temp7 = A[8 * l + i][8 * k + 7];
					B[8 * k + 0][8 * l + i] = temp0;
					B[8 * k + 1][8 * l + i] = temp1;
					B[8 * k + 2][8 * l + i] = temp2;
					B[8 * k + 3][8 * l + i] = temp3;
					B[8 * k + 0][8 * l + i + 4] = temp4;
					B[8 * k + 1][8 * l + i + 4] = temp5;
					B[8 * k + 2][8 * l + i + 4] = temp6;
					B[8 * k + 3][8 * l + i + 4] = temp7;
				}
				for (i = 0; i < 4; i++) {//A���½���B���Ͻ��û�
					temp0 = A[8 * l + 4][8 * k + i];
					temp1 = A[8 * l + 5][8 * k + i];
					temp2 = A[8 * l + 6][8 * k + i];
					temp3 = A[8 * l + 7][8 * k + i];
					temp4 = B[8 * k + i][8 * l + 4];
					temp5 = B[8 * k + i][8 * l + 5];
					temp6 = B[8 * k + i][8 * l + 6];
					temp7 = B[8 * k + i][8 * l + 7];
					B[8 * k + i][8 * l + 4] = temp0;
					B[8 * k + i][8 * l + 5] = temp1;
					B[8 * k + i][8 * l + 6] = temp2;
					B[8 * k + i][8 * l + 7] = temp3;
					B[8 * k + i + 4][8 * l + 0] = temp4;
					B[8 * k + i + 4][8 * l + 1] = temp5;
					B[8 * k + i + 4][8 * l + 2] = temp6;
					B[8 * k + i + 4][8 * l + 3] = temp7;
				}
				for (i = 0; i < 4; i++) {//AB���½��û���ͬʱת��k
					temp0 = A[8 * l + i + 4][8 * k + 4];
					temp1 = A[8 * l + i + 4][8 * k + 5];
					temp2 = A[8 * l + i + 4][8 * k + 6];
					temp3 = A[8 * l + i + 4][8 * k + 7];
					B[8 * k + 4][8 * l + i + 4] = temp0;
					B[8 * k + 5][8 * l + i + 4] = temp1;
					B[8 * k + 6][8 * l + i + 4] = temp2;
					B[8 * k + 7][8 * l + i + 4] = temp3;
				}
			}
		}
	}
	else if ((M == 32) && (N == 32))
	{
	for (l = 0; l < 4; l++) {
		for (k = 0; k < 4; k++) {
			for (i = 8 * l; i < 8 * l + 8; i++) {
				val0 = A[i][0 + 8 * k];
				val1 = A[i][1 + 8 * k];
				val2 = A[i][2 + 8 * k];
				val3 = A[i][3 + 8 * k];
				val4 = A[i][4 + 8 * k];
				val5 = A[i][5 + 8 * k];
				val6 = A[i][6 + 8 * k];
				val7 = A[i][7 + 8 * k];
				B[0 + 8 * k][i] = val0;
				B[1 + 8 * k][i] = val1;
				B[2 + 8 * k][i] = val2;
				B[3 + 8 * k][i] = val3;
				B[4 + 8 * k][i] = val4;
				B[5 + 8 * k][i] = val5;
				B[6 + 8 * k][i] = val6;
				B[7 + 8 * k][i] = val7;
			}
		}
	}

	}
	else if ((M == 61) && (N == 67))
	{
	for (k = 0; k + 16 < N; k += 16) {
		for (l = 0; l + 16 < M; l += 16) {
			for (i = k; i < k + 16; i++) {
				temp0 = A[i][l + 0];
				temp1 = A[i][l + 1];
				temp2 = A[i][l + 2];
				temp3 = A[i][l + 3];
				temp4 = A[i][l + 4];
				temp5 = A[i][l + 5];
				temp6 = A[i][l + 6];
				temp7 = A[i][l + 7];
				B[l + 0][i] = temp0;
				B[l + 1][i] = temp1;
				B[l + 2][i] = temp2;
				B[l + 3][i] = temp3;
				B[l + 4][i] = temp4;
				B[l + 5][i] = temp5;
				B[l + 6][i] = temp6;
				B[l + 7][i] = temp7;

				temp0 = A[i][l + 8];
				temp1 = A[i][l + 9];
				temp2 = A[i][l + 10];
				temp3 = A[i][l + 11];
				temp4 = A[i][l + 12];
				temp5 = A[i][l + 13];
				temp6 = A[i][l + 14];
				temp7 = A[i][l + 15];
				B[l + 8][i] = temp0;
				B[l + 9][i] = temp1;
				B[l + 10][i] = temp2;
				B[l + 11][i] = temp3;
				B[l + 12][i] = temp4;
				B[l + 13][i] = temp5;
				B[l + 14][i] = temp6;
				B[l + 15][i] = temp7;

			}
		}
	}

	for (i = k; i < N; i++)
		for (j = 0; j < M; j++)
			B[j][i] = A[i][j];
	for (i = 0; i < k; i++)
		for (j = l; j < M; j++)
			B[j][i] = A[i][j];
	}
	else
	{
	for (i = 0; i < N; i++) {
		for (j = 0; j < M; ++j) {
			if (A[i][j] != B[j][i]) {
			}
		}
	}
	}
	//for (k = 0; k < 8; k++) {
	//	for (l = 0; l < 8; l++) {
	//		for (i = 0; i < 4; i++) {//��һ��4x8�ĳ�����ת����ֵ��B��
	//			temp0 = A[8 * l + i][8 * k + 0];
	//			temp1 = A[8 * l + i][8 * k + 1];
	//			temp2 = A[8 * l + i][8 * k + 2];
	//			temp3 = A[8 * l + i][8 * k + 3];
	//			temp4 = A[8 * l + i][8 * k + 4];
	//			temp5 = A[8 * l + i][8 * k + 5];
	//			temp6 = A[8 * l + i][8 * k + 6];
	//			temp7 = A[8 * l + i][8 * k + 7];
	//			B[8 * k + 0][8 * l + i] = temp0;
	//			B[8 * k + 1][8 * l + i] = temp1;
	//			B[8 * k + 2][8 * l + i] = temp2;
	//			B[8 * k + 3][8 * l + i] = temp3;
	//			B[8 * k + i][8 * l + 4] = temp4;
	//			B[8 * k + i][8 * l + 5] = temp5;
	//			B[8 * k + i][8 * l + 6] = temp6;
	//			B[8 * k + i][8 * l + 7] = temp7;
	//		}
	//		for (i = 4; i < 8; i++) {//�ڶ���4x8
	//			temp0 = A[8 * l + i][8 * k + 0];
	//			temp1 = A[8 * l + i][8 * k + 1];
	//			temp2 = A[8 * l + i][8 * k + 2];
	//			temp3 = A[8 * l + i][8 * k + 3];
	//			temp4 = A[8 * l + i][8 * k + 4];
	//			temp5 = A[8 * l + i][8 * k + 5];
	//			temp6 = A[8 * l + i][8 * k + 6];
	//			temp7 = A[8 * l + i][8 * k + 7];
	//			B[8 * k + i][8 * l + 0] = temp0;
	//			B[8 * k + i][8 * l + 1] = temp1;
	//			B[8 * k + i][8 * l + 2] = temp2;
	//			B[8 * k + i][8 * l + 3] = temp3;
	//			B[8 * k + 4][8 * l + i] = temp4;
	//			B[8 * k + 5][8 * l + i] = temp5;
	//			B[8 * k + 6][8 * l + i] = temp6;
	//			B[8 * k + 7][8 * l + i] = temp7;
	//		}
	//		for (i = 0; i < 4; i++) {//���������»���λ��
	//			temp0 = B[8 * k + i + 4][8 * l + 0];
	//			temp1 = B[8 * k + i + 4][8 * l + 1];
	//			temp2 = B[8 * k + i + 4][8 * l + 2];
	//			temp3 = B[8 * k + i + 4][8 * l + 3];
	//			temp4 = B[8 * k + i][8 * l + 4];
	//			temp5 = B[8 * k + i][8 * l + 5];
	//			temp6 = B[8 * k + i][8 * l + 6];
	//			temp7 = B[8 * k + i][8 * l + 7];
	//			B[8 * k + i + 4][8 * l + 0] = temp4;
	//			B[8 * k + i + 4][8 * l + 1] = temp5;
	//			B[8 * k + i + 4][8 * l + 2] = temp6;
	//			B[8 * k + i + 4][8 * l + 3] = temp7;
	//			B[8 * k + i][8 * l + 4] = temp0;
	//			B[8 * k + i][8 * l + 5] = temp1;
	//			B[8 * k + i][8 * l + 6] = temp2;
	//			B[8 * k + i][8 * l + 7] = temp3;
	//		}
	//		//���Ϸֿ�����ֶ�ת��
	//		temp0 = B[8 * k + 0][8 * l + 5];
	//		temp1 = B[8 * k + 0][8 * l + 6];
	//		temp2 = B[8 * k + 0][8 * l + 7];
	//		temp3 = B[8 * k + 1][8 * l + 6];
	//		temp4 = B[8 * k + 1][8 * l + 7];
	//		temp5 = B[8 * k + 2][8 * l + 7];
	//		B[8 * k + 0][8 * l + 5] = B[8 * k + 1][8 * l + 4];
	//		B[8 * k + 0][8 * l + 6] = B[8 * k + 2][8 * l + 4];
	//		B[8 * k + 0][8 * l + 7] = B[8 * k + 3][8 * l + 4];
	//		B[8 * k + 1][8 * l + 6] = B[8 * k + 2][8 * l + 5];
	//		B[8 * k + 1][8 * l + 7] = B[8 * k + 3][8 * l + 5];
	//		B[8 * k + 2][8 * l + 7] = B[8 * k + 3][8 * l + 6];
	//		B[8 * k + 1][8 * l + 4] = temp0;
	//		B[8 * k + 2][8 * l + 4] = temp1;
	//		B[8 * k + 3][8 * l + 4] = temp2;
	//		B[8 * k + 2][8 * l + 5] = temp3;
	//		B[8 * k + 3][8 * l + 5] = temp4;
	//		B[8 * k + 3][8 * l + 6] = temp5;
	//		//���¾����ֶ�ת��
	//		temp0 = B[8 * k + 4][8 * l + 1];
	//		temp1 = B[8 * k + 4][8 * l + 2];
	//		temp2 = B[8 * k + 4][8 * l + 3];
	//		temp3 = B[8 * k + 5][8 * l + 2];
	//		temp4 = B[8 * k + 5][8 * l + 3];
	//		temp5 = B[8 * k + 6][8 * l + 3];
	//		B[8 * k + 4][8 * l + 1] = B[8 * k + 5][8 * l + 0];
	//		B[8 * k + 4][8 * l + 2] = B[8 * k + 6][8 * l + 0];
	//		B[8 * k + 4][8 * l + 3] = B[8 * k + 7][8 * l + 0];
	//		B[8 * k + 5][8 * l + 2] = B[8 * k + 6][8 * l + 1];
	//		B[8 * k + 5][8 * l + 3] = B[8 * k + 7][8 * l + 1];
	//		B[8 * k + 6][8 * l + 3] = B[8 * k + 7][8 * l + 2];
	//		B[8 * k + 5][8 * l + 0] = temp0;
	//		B[8 * k + 6][8 * l + 0] = temp1;
	//		B[8 * k + 7][8 * l + 0] = temp2;
	//		B[8 * k + 6][8 * l + 1] = temp3;
	//		B[8 * k + 7][8 * l + 1] = temp4;
	//		B[8 * k + 7][8 * l + 2] = temp5;
	//		//for (i = 8 * k; i < 8 * k + 4; i++) {//���Ϸֿ����ת��
	//		//	temp4 = B[i][8 * l + 4];
	//		//	temp5 = B[i][8 * l + 5];
	//		//	temp6 = B[i][8 * l + 6];
	//		//	temp7 = B[i][8 * l + 7];
	//		//	B[8 * k + 4][8 * l + 0] = temp4;
	//		//	B[8 * k + 5][8 * l + 0] = temp5;
	//		//	B[8 * k + 6][8 * l + 0] = temp6;
	//		//	B[8 * k + 7][8 * l + 0] = temp7;
	//		//}
	//		//for (i = 8 * k + 4; i < 8 * k + 8; i++) {//���·ֿ����ת��
	//		//	temp0 = B[i][8 * l + 0];
	//		//	temp1 = B[i][8 * l + 1];
	//		//	temp2 = B[i][8 * l + 2];
	//		//	temp3 = B[i][8 * l + 3];
	//		//	B[8 * k + 4][8 * l + 0] = temp0;
	//		//	B[8 * k + 5][8 * l + 0] = temp1;
	//		//	B[8 * k + 6][8 * l + 0] = temp2;
	//		//	B[8 * k + 7][8 * l + 0] = temp3;
	//		//}
	//	}
	//}
}
//char transpose_submit_desc[] = "Transpose submission";
//void transpose_submit(int M, int N, int A[N][M], int B[M][N])
//{
//	int i;
//	int k, l;
//	int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
//	for (k = 0; k < 8; k++) {
//		for (l = 0; l < 8; l++) {
//			for (i = 0; i < 4; i++) {//��һ��4x8�ĳ�����ת����ֵ��B��,ǰ4x4����������ת��
//				temp0 = A[8 * l + i][8 * k + 0];
//				temp1 = A[8 * l + i][8 * k + 1];
//				temp2 = A[8 * l + i][8 * k + 2];
//				temp3 = A[8 * l + i][8 * k + 3];
//				temp4 = A[8 * l + i][8 * k + 4];
//				temp5 = A[8 * l + i][8 * k + 5];
//				temp6 = A[8 * l + i][8 * k + 6];
//				temp7 = A[8 * l + i][8 * k + 7];
//				B[8 * k + 0][8 * l + i] = temp0;
//				B[8 * k + 1][8 * l + i] = temp1;
//				B[8 * k + 2][8 * l + i] = temp2;
//				B[8 * k + 3][8 * l + i] = temp3;
//				B[8 * k + 0][8 * l + i + 4] = temp4;
//				B[8 * k + 1][8 * l + i + 4] = temp5;
//				B[8 * k + 2][8 * l + i + 4] = temp6;
//				B[8 * k + 3][8 * l + i + 4] = temp7;
//			}
//			for (i = 0; i < 4; i++) {//A���½���B���Ͻ��û�
//				temp0 = A[8 * l + 4][8 * k + i];
//				temp1 = A[8 * l + 5][8 * k + i];
//				temp2 = A[8 * l + 6][8 * k + i];
//				temp3 = A[8 * l + 7][8 * k + i];
//				temp4 = B[8 * k + i][8 * l + 4];
//				temp5 = B[8 * k + i][8 * l + 5];
//				temp6 = B[8 * k + i][8 * l + 6];
//				temp7 = B[8 * k + i][8 * l + 7];
//				B[8 * k + i][8 * l + 4] = temp0;
//				B[8 * k + i][8 * l + 5] = temp1;
//				B[8 * k + i][8 * l + 6] = temp2;
//				B[8 * k + i][8 * l + 7] = temp3;
//				B[8 * k + i + 4][8 * l + 0] = temp4;
//				B[8 * k + i + 4][8 * l + 1] = temp5;
//				B[8 * k + i + 4][8 * l + 2] = temp6;
//				B[8 * k + i + 4][8 * l + 3] = temp7;
//			}
//			for (i = 0; i < 4; i++) {//AB���½��û���ͬʱת��k
//				temp0 = A[8 * l + i + 4][8 * k + 4];
//				temp1 = A[8 * l + i + 4][8 * k + 5];
//				temp2 = A[8 * l + i + 4][8 * k + 6];
//				temp3 = A[8 * l + i + 4][8 * k + 7];
//				B[8 * k + 4][8 * l + i + 4] = temp0;
//				B[8 * k + 5][8 * l + i + 4] = temp1;
//				B[8 * k + 6][8 * l + i + 4] = temp2;
//				B[8 * k + 7][8 * l + i + 4] = temp3;
//			}
//		}
//	}
//}

char transpose_submit_desc32[] = "Transpose 32x32 submission";
void transpose_submit32(int M, int N, int A[N][M], int B[M][N])
{
	int i;
	int k, l;
	int val0, val1, val2, val3, val4, val5, val6, val7;

	for (l = 0; l < 4; l++) {
		for (k = 0; k < 4; k++) {
			for (i = 8 * l; i < 8 * l + 8; i++) {
				val0 = A[i][0 + 8 * k];
				val1 = A[i][1 + 8 * k];
				val2 = A[i][2 + 8 * k];
				val3 = A[i][3 + 8 * k];
				val4 = A[i][4 + 8 * k];
				val5 = A[i][5 + 8 * k];
				val6 = A[i][6 + 8 * k];
				val7 = A[i][7 + 8 * k];
				B[0 + 8 * k][i] = val0;
				B[1 + 8 * k][i] = val1;
				B[2 + 8 * k][i] = val2;
				B[3 + 8 * k][i] = val3;
				B[4 + 8 * k][i] = val4;
				B[5 + 8 * k][i] = val5;
				B[6 + 8 * k][i] = val6;
				B[7 + 8 * k][i] = val7;
			}
		}
	}
}
/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 
	//registerTransFunction(transpose_submit32, transpose_submit_desc32);

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

